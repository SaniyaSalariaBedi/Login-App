import React from 'react';
import { useState, useEffect } from 'react';
import { Form, FormGroup, FormControl, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import {Container, Row, Col} from 'react-bootstrap';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../index.css';
import useEnhancedEffect from '@mui/material/utils/useEnhancedEffect';

const LoginPage = () => {
    const navigate = useNavigate();
    const [userName, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    let loginSchema = {
        "userName":"",
        "email": "",
        "password": ""
    }
    const handleChange = (e) => {

        if(e.target.name === "userName") {
            setUserName(e.target.value);
        }else if (e.target.name === "email") {
            setEmail(e.target.value);
        }else setPassword(e.target.value);
    }
    const handleFormSubmit = (e) => {
        e.preventDefault();
        loginSchema = {
            "userName": userName,
            "email": email,
            "password": password
        }
        localStorage.setItem('loginSchema', JSON.stringify(loginSchema));
        navigate('/home');
        console.log("FORM SUBMIT!", loginSchema);
    }
    const getDataFromLocalStorage =() =>{
        if (localStorage.getItem("loginSchema") !== null) {
            console.log('here it has data');
            let userCredentials = JSON.parse(localStorage.getItem("loginSchema"));
            console.log("userCredentials", userCredentials);
            setEmail(userCredentials.email);
            setPassword(userCredentials.password);
            setUserName(userCredentials.userName);
          }
    }
    useEffect(()=>{
        getDataFromLocalStorage();
    },[]);
    return (
        <Container>
            <Row>
                <Col xs={6}> <h1>Login Page </h1>
                    <Form horizontal id="loginForm">
                    <FormGroup controlId="formUserName">
                            <FormControl type="text" name="userName" placeholder="User Name" onChange={handleChange} value={userName} />
                        </FormGroup>
                        <FormGroup controlId="formEmail">
                            <FormControl type="email" name="email" placeholder="Email Address" onChange={handleChange} value={email} />
                        </FormGroup>
                        <FormGroup controlId="formPassword">
                            <FormControl type="password" name="password" placeholder="Password" onChange={handleChange} value={password} />
                        </FormGroup>
                        <FormGroup controlId="formSubmit">
                            <Button variant="secondary" size="lg" type="submit" disabled={userName == " " || email == " " || password == " "} onClick={handleFormSubmit}>
                                Submit
                            </Button>
                        </FormGroup>
                    </Form>
                </Col>
            </Row>
        </Container>
           
    )
}

export default LoginPage;